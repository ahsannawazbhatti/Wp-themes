<?php
/**
 * The template to display the socials in the footer
 *
 * @package CORBESIER
 * @since CORBESIER 1.0.10
 */


// Socials
if ( corbesier_is_on( corbesier_get_theme_option( 'socials_in_footer' ) ) ) {
	$corbesier_output = corbesier_get_socials_links();
	if ( '' != $corbesier_output ) {
		?>
		<div class="footer_socials_wrap socials_wrap">
			<div class="footer_socials_inner">
				<?php corbesier_show_layout( $corbesier_output ); ?>
			</div>
		</div>
		<?php
	}
}
