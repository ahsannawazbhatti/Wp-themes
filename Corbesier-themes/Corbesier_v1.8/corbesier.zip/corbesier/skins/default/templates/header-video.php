<?php
/**
 * The template to display the background video in the header
 *
 * @package CORBESIER
 * @since CORBESIER 1.0.14
 */
$corbesier_header_video = corbesier_get_header_video();
$corbesier_embed_video  = '';
if ( ! empty( $corbesier_header_video ) && ! corbesier_is_from_uploads( $corbesier_header_video ) ) {
	if ( corbesier_is_youtube_url( $corbesier_header_video ) && preg_match( '/[=\/]([^=\/]*)$/', $corbesier_header_video, $matches ) && ! empty( $matches[1] ) ) {
		?><div id="background_video" data-youtube-code="<?php echo esc_attr( $matches[1] ); ?>"></div>
		<?php
	} else {
		?>
		<div id="background_video"><?php corbesier_show_layout( corbesier_get_embed_video( $corbesier_header_video ) ); ?></div>
		<?php
	}
}
